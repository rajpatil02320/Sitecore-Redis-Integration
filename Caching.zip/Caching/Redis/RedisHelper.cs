﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using StackExchange.Redis;
using Newtonsoft.Json;
using SPJ.Foundation.Logging.Log;

namespace SPJ.Foundation.Caching.Redis
{
    public static class RedisHelper
    {
        static readonly string Connstr = Sitecore.Configuration.Settings.GetSetting("Redis.Constr", "");
        static ConnectionMultiplexer _redis;
        static readonly object Locker = new object();
        public static readonly TimeSpan DefaultCacheTime = new TimeSpan(45, 4, 0, 0);



        /// <summary>
        /// Cache manager
        /// </summary>
        public static ConnectionMultiplexer Manager
        {
            get
            {
                if (_redis == null)
                {
                    lock (Locker)
                    {
                        if (_redis != null) return _redis;

                        _redis = GetManager();
                        return _redis;
                    }
                }
                Logger.VeriskDXPLog.Info("RedisHelper:Manager- redis updated");
                return _redis;
            }
        }

        /// <summary>
        /// Get cache manager
        /// </summary>
        /// <param name="connectionString"></param>
        /// <returns></returns>
        static ConnectionMultiplexer GetManager(string connectionString = null)
        {
            Logger.VeriskDXPLog.Info("RedisHelper:GetManager");
            if (string.IsNullOrEmpty(connectionString))
            {
                connectionString = connectionString ?? Connstr;
            }
            var sslRedis = Sitecore.Configuration.Settings.GetSetting("Verisk.redis.ssl.enabled");
            ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => true;
            Logger.VeriskDXPLog.Info("RedisHelper:GetManager- Server validation");
            var options = ConfigurationOptions.Parse(connectionString);
            options.ConnectTimeout = 2000;
            options.KeepAlive = 180;
            options.SyncTimeout = 2000;
            options.ConnectRetry = 3;
            options.AbortOnConnectFail = false;

            options.Ssl = sslRedis == "1";//On local set the Options.ssl to false
            options.CertificateValidation += (a, b, c, d) => true;

            ConnectionMultiplexer connection = null;
            try
            {
                connection = ConnectionMultiplexer.Connect(options);
                Logger.VeriskDXPLog.Info("RedisHelper:GetManager- Connection updated");
            }
            catch(Exception ex)
            {
                Logger.VeriskDXPLog.Error("In Redishelper Get Manager " + ex.InnerException.Message);
            }
            return connection;
        }


        #region String 

        /// <summary>
        ///  key value
        /// </summary>
        /// <param name="key">Redis Key</param>
        /// <param name="value"></param>
        /// <param name="expiry"></param>
        /// <returns></returns>
        public static bool SetStringKey(string key, string value, TimeSpan? expiry = null)
        {
            expiry = expiry ?? DefaultCacheTime;
            var db = Manager.GetDatabase();
            return db.StringSet(key.ToLower(), value, expiry);
        }

        /// <summary>
        ///  key value
        /// </summary>
        /// <param name="arr">key</param>
        /// <returns></returns>
        public static bool SetStringKey(KeyValuePair<RedisKey, RedisValue>[] arr)
        {
            var db = Manager.GetDatabase();
            return db.StringSet(arr);
        }

        /// <summary>
        ///  
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <param name="obj"></param>
        /// <param name="expiry"></param>
        /// <returns></returns>
        public static bool SetStringKey<T>(string key, T obj, TimeSpan? expiry = null)
        {
            expiry = expiry ?? DefaultCacheTime;
            string json = JsonConvert.SerializeObject(obj);
            var db = Manager.GetDatabase();

            bool setKey = false;

            try
            {
                setKey=  db.StringSet(key.ToLower(), json, expiry);
            }
            catch (Exception ex)
            {
                Logger.VeriskDXPLog.Error("Inside Redis helper SetStringKey " + ex.InnerException.Message);
            }

            return setKey;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="key">Redis Key</param>
        /// <returns></returns>

        public static string GetStringKey(string key)
        {
            var db = Manager.GetDatabase();
            string val = db.StringGet(key.ToLower());
            return string.IsNullOrWhiteSpace(val) ? string.Empty : val.Trim('"');
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="listKey"></param>
        /// <returns></returns>
        public static RedisValue[] GetStringKey(List<RedisKey> listKey)
        {
            var db = Manager.GetDatabase();
            return db.StringGet(listKey.ToArray());
        }

        /// <summary>
        ///  
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public static string GetObjectKey(string key)
        {
            var db = Manager.GetDatabase();

            string redisKey = string.Empty;

            try
            {
                var radisVal = db.StringGet(key.ToLower());

                redisKey = !string.IsNullOrEmpty(radisVal) ? radisVal.ToString() : "";
            }
            catch (Exception ex)
            {
                Logger.VeriskDXPLog.Error("Inside Redis Helper GetObjectKey " + ex.InnerException.Message);
            }

            return redisKey;
           
        }

        /// <summary>
        ///  
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public static T GetObjectKey<T>(string key)
        {
            var db = Manager.GetDatabase();

            if ((db.StringGet(key.ToLower()) == RedisValue.Null))
            {
                return default(T);
            }

            var redisKey = db.StringGet(key.ToLower());

            return JsonConvert.DeserializeObject<T>(redisKey.ToString());
        }

        public static void DeleteKeyByPrefix(string prefix)
        {
            var server = Manager.GetServer(Connstr);
            var keys = server.Keys(pattern: $"*{prefix.ToLower()}*");
            var db = Manager.GetDatabase();
            db.KeyDelete(keys.ToArray());
        }

        #endregion

        #region Hash

        /// <summary>
        ///  
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key">Redis Key</param>
        /// <param name="list"> </param>
        /// <param name="getModelId"></param>
        public static void HashSet<T>(string key, List<T> list, Func<T, string> getModelId)
        {
            List<HashEntry> listHashEntry = new List<HashEntry>();
            foreach (var item in list)
            {
                string json = JsonConvert.SerializeObject(item);
                listHashEntry.Add(new HashEntry(getModelId(item), json));
            }

            var db = Manager.GetDatabase();
            db.HashSet(key.ToLower(), listHashEntry.ToArray());
        }

        /// <summary>
        ///  
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key">Redis Key</param>
        /// <param name="hasFildValue">RedisValue</param>
        /// <returns></returns>
        public static T GetHashKey<T>(string key, string hasFildValue)
        {
            if (!string.IsNullOrWhiteSpace(key) && !string.IsNullOrWhiteSpace(hasFildValue))
            {
                var db = Manager.GetDatabase();
                RedisValue value = db.HashGet(key.ToLower(), hasFildValue);
                if (!value.IsNullOrEmpty)
                {
                    return JsonConvert.DeserializeObject<T>(value);
                }
            }
            return default(T);
        }

        /// <summary>
        ///  
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key">Redis Key</param>
        /// <param name="listhashFields">RedisValue value</param>
        /// <returns></returns>
        public static List<T> GetHashKey<T>(string key, List<RedisValue> listhashFields)
        {
            List<T> result = new List<T>();
            if (!string.IsNullOrWhiteSpace(key) && listhashFields.Count > 0)
            {
                var db = Manager.GetDatabase();

                RedisValue[] value = db.HashGet(key.ToLower(), listhashFields.ToArray());
                foreach (var item in value)
                {
                    if (!item.IsNullOrEmpty)
                    {
                        result.Add(JsonConvert.DeserializeObject<T>(item));
                    }
                }
            }
            return result;
        }

        /// <summary>
        ///  Redis key
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <returns></returns>
        public static List<T> GetHashAll<T>(string key)
        {
            var db = Manager.GetDatabase();

            List<T> result = new List<T>();
            RedisValue[] arr = db.HashKeys(key.ToLower());
            foreach (var item in arr)
            {
                if (!item.IsNullOrEmpty)
                {
                    result.Add(JsonConvert.DeserializeObject<T>(item));
                }
            }
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <returns></returns>
        public static List<T> HashGetAll<T>(string key)
        {
            var db = Manager.GetDatabase();

            List<T> result = new List<T>();
            HashEntry[] arr = db.HashGetAll(key.ToLower());
            foreach (var item in arr)
            {
                if (!item.Value.IsNullOrEmpty)
                {
                    result.Add(JsonConvert.DeserializeObject<T>(item.Value));
                }
            }
            return result;
        }

        /// <summary>
        ///  
        /// </summary>
        /// <param name="key"></param>
        /// <param name="hashField"></param>
        /// <returns></returns>
        public static bool DeleteHase(RedisKey key, RedisValue hashField)
        {
            var db = Manager.GetDatabase();
            return db.HashDelete(key, hashField);
        }

        #endregion

        #region key

        /// <summary>
        ///  
        /// </summary>
        /// <param name="key">redis key</param>
        /// <returns> </returns>
        public static bool KeyDelete(string key)
        {
            var db = Manager.GetDatabase();
          
            bool redisKey = false;

            try
            {
                redisKey = db.KeyDelete(key.ToLower());
            }
            catch (Exception ex)
            {
                Logger.VeriskDXPLog.Error("Inside Redis helper KeyDelete " + ex.InnerException.Message);
            }

            return redisKey;
        }


        /// <summary>
        ///   key
        /// </summary>
        /// <param name="keys">rediskey</param>
        /// <returns> </returns>
        public static long KeyDelete(RedisKey[] keys)
        {
            var db = Manager.GetDatabase();
            return db.KeyDelete(keys);
        }

        public static bool RemoveKey(string key)
        {
            var db = Manager.GetDatabase();
            
            bool redisKey = false;

            try
            {
                redisKey = db.KeyDelete(key.ToLower());
            }
            catch (Exception ex)
            {
                Logger.VeriskDXPLog.Error("Inside Redis helper RemoveKey " + ex.InnerException.Message);
            }

            return redisKey;
        }
        /// <summary>
        ///  
        /// </summary>
        /// <param name="key">redis key</param>
        /// <returns></returns>
        public static bool KeyExists(string key)
        {
            var db = Manager.GetDatabase();
          
            bool keyExits = false;

            try
            {
                keyExits = db.KeyExists(key.ToLower());
            }
            catch (Exception ex)
            {
                Logger.VeriskDXPLog.Error("Inside Redis helper KeyExists " + ex.InnerException.Message);
            }

            return keyExits;
        }

        /// <summary>
        ///  
        /// </summary>
        /// <param name="key"> redis key</param>
        /// <param name="newKey"> redis key</param>
        /// <returns></returns>
        public static bool KeyRename(string key, string newKey)
        {
            var db = Manager.GetDatabase();
            return db.KeyRename(key.ToLower(), newKey.ToLower());
        }
        #endregion


        #region Serialize/DeSerialize
        public static T Deserialize<T>(byte[] serializedObject)
        {
            if (serializedObject == null)
                return default(T);

            var jsonString = Encoding.UTF8.GetString(serializedObject);
            return JsonConvert.DeserializeObject<T>(jsonString);
        }
        public static byte[] Serialize(object item)
        {
            var jsonString = JsonConvert.SerializeObject(item);
            return Encoding.UTF8.GetBytes(jsonString);
        }
        #endregion
    }
}