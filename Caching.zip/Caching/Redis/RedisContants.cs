﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace SPJ.Foundation.Caching.Redis
{
    public static class RedisContants
    {
        /// <summary>
        /// Get Redis ip 
        /// </summary>
        public static string RedisIp
        {
            get
            {
                string redisIp = ConfigurationManager.AppSettings["RedisIp"];//make changes to get the info from ssp configuration file 
                return redisIp;
            }
        }

        /// <summary>
        /// Get Redis port
        /// </summary>
        public static string RedisPort
        {
            get
            {
                string redisPort = ConfigurationManager.AppSettings["RedisPort"]; //make changes to get the info from ssp configuration file 
                return redisPort;
            }
        }


        public static string RedisPass
        {
            get
            {
                string redisPass = ConfigurationManager.AppSettings["RedisPass"];//make changes to get the info from ssp configuration file 
                return redisPass;
            }
        }
    }
}