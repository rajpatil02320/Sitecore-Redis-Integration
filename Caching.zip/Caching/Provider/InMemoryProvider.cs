﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Caching;

namespace SPJ.Foundation.Caching.Provider
{
    public class InMemoryProvider : CacheProviderBase<MemoryCache>
    {
        readonly string _site;
        public InMemoryProvider() : this("SPJ")
        {

        }
        public InMemoryProvider(string site)
        {
            this._site = site;
        }
        public InMemoryProvider(string site, int cacheDuration) : this(site)
        {
            this.CacheDuration = cacheDuration;
        }
        /// <summary>
        /// Initialze the cache
        /// </summary>
        /// <returns></returns>
        protected override MemoryCache InitCache()
        {
            return string.IsNullOrEmpty(this._site) ? MemoryCache.Default : new MemoryCache(this._site);
        }


        /// <summary>
        /// Get Cache by cache key
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key">Cache key</param>
        /// <returns></returns>
        public override T GetValue<T>(string key)
        {
            if (this.Exists(key))
            {
                var value = (T)this.Cache[key];
                return value;
            }

            return default(T);

        }

        /// <summary>
        /// set cache
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key">Cache key</param>
        /// <param name="value">Cache value</param>
        /// <param name="duration">Cache duration</param>
        public override void SetValue<T>(string key, T value, int duration)
        {
            var policy = new CacheItemPolicy { AbsoluteExpiration = DateTime.Now.AddMinutes(duration) };
            if (null != value)
                this.Cache.Set(key, value, policy);
        }

        /// <summary>
        /// Set cache sliding expriation
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key">Cache key</param>
        /// <param name="value">Cache value</param>
        /// <param name="duration">Cache duration</param>
        public override void SetSliding<T>(string key, T value, int duration)
        {
            var policy = new CacheItemPolicy { SlidingExpiration = new TimeSpan(0, duration, 0) };
            this.Cache.Set(key, value, policy);
        }


        /// <summary>
        /// Check cache exist
        /// </summary>
        /// <param name="key">Cache key</param>
        /// <returns></returns>
        public override bool Exists(string key)
        {
            return this.Cache[key] != null;
        }

        /// <summary>
        /// Remove Cache
        /// </summary>
        /// <param name="key"></param>
        public override void Remove(string key)
        {
            this.Cache.Remove(key);
        }


        public override void Clear()
        {
            this.Cache.Trim(100);
        }
    }
}