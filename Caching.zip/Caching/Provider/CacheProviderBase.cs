﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SPJ.Foundation.Caching.Contracts;

namespace SPJ.Foundation.Caching.Provider
{
    public abstract class CacheProviderBase
    {
        protected CacheProviderBase() { }
        protected static readonly object lockObject = new object();
    }

    /// <summary>
    /// Abstract cache base
    /// </summary>
    /// <typeparam name="TCache"></typeparam>
    public abstract class CacheProviderBase<TCache> : CacheProviderBase, ICache
    {

        /// <summary>
        /// Cache duration
        /// </summary>
        public int CacheDuration { get; set; }

        private TCache _cache;
        /// <summary>
        /// Cache
        /// </summary>
        public TCache Cache
        {
            get
            {
                if (_cache == null)
                {
                    _cache = InitCache();
                }
                return _cache;
            }
        }

        /// <summary>
        /// Cache duration
        /// </summary>
        private const int DefaultCacheDurationMinutes = 60;

        /// <summary>
        /// cache provider base constructor
        /// </summary>
        protected CacheProviderBase()
        {

            this.CacheDuration = DefaultCacheDurationMinutes;
        }

        /// <summary>
        /// Initalize the Cache
        /// </summary>
        /// <returns></returns>
        protected abstract TCache InitCache();

        public virtual T Get<T>(string key)
        {
            var value = this.GetValue<T>(GetKey(key));

            return value;
        }

        /// <summary>
        /// Set the Cache
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key">Cache Key</param>
        /// <param name="value">Cache Value</param>
        public virtual void Set<T>(string key, T value)
        {
            lock (lockObject)
            {
                key = GetKey(key);
                this.SetValue<T>(key, value, this.CacheDuration);
            }
        }

        /// <summary>
        /// Set the Cache sliding expration
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"> Cache key</param>
        /// <param name="value">Cache value</param>
        public virtual void SetSliding<T>(string key, T value)
        {
            this.SetSliding<T>(GetKey(key), value, this.CacheDuration);
        }




        /// <summary>
        /// Get or Set Cache
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key">Cache key</param>
        /// <param name="valFunction">Cache delegate function</param>
        /// <param name="duration">Cache duration</param>
        /// <returns></returns>
        public virtual T GetOrSet<T>(string key, Func<T> valFunction, int duration) where T : class
        {
            var value = this.GetValue<T>(GetKey(key));
            if (default(T) == value)
            {
                lock (lockObject)
                {
                    value = this.GetValue<T>(GetKey(key));
                    if (default(T) == value)
                    {
                        value = valFunction();
                        this.SetValue(GetKey(key), value, duration);
                    }
                }
            }

            return value;
        }

        /// <summary>
        /// Gets the or set.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key">The key.</param>
        /// <param name="valFunction">The value function.</param>
        /// <returns></returns>
        public virtual T GetOrSet<T>(string key, Func<T> valFunction) where T : class
        {
            var value = this.GetValue<T>(GetKey(key));
            if (null == value)
            {
                value = valFunction();
                this.SetValue(GetKey(key), value, this.CacheDuration);
            }

            return value;
        }

        protected virtual string GetKey(string baseKey)
        {
            return $"verisk_en_{baseKey}".ToUpperInvariant();
        }

        #region Abstract
        public abstract void SetValue<T>(string key, T value, int duration);

        public abstract T GetValue<T>(string key);


        public abstract void SetSliding<T>(string key, T value, int duration);


        public abstract bool Exists(string key);


        public abstract void Remove(string key);

        public abstract void Clear();

        public void SetNoLock<T>(string key, T value)
        {
            key = GetKey(key);
            this.SetValue<T>(key, value, this.CacheDuration);
        }

        public void SetNoLock<T>(string key, Func<T> value)
        {
            key = GetKey(key);
            this.SetValue(key, value, this.CacheDuration);
        }
        #endregion
    }
}