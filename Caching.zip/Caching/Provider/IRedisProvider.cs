﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SPJ.Foundation.Caching.Contracts;

namespace SPJ.Foundation.Caching.Provider
{
    public interface IRedisProvider : ICache
    {
        T GetValue<T>(string key);
        void SetValue<T>(string key, T value, int duration);
    }
}
