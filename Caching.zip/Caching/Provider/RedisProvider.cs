﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using StackExchange.Redis;
using SPJ.Foundation.Caching.Redis;

namespace SPJ.Foundation.Caching.Provider
{
    /// <summary>
    /// Redis cache
    /// </summary>
    public class RedisProvider : CacheProviderBase<IDatabase>, IRedisProvider
    {
        /// <summary>
        /// Initialze the cache
        /// </summary>
        /// <returns></returns>
        protected override IDatabase InitCache() => default;

        /// <summary>
        /// Check if cache exist
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public override bool Exists(string key)
        {

            return RedisHelper.KeyExists(key);

        }

        /// <summary>
        /// Get cache
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key">Cache key</param>
        /// <returns></returns>
        public override T GetValue<T>(string key)
        {
            return RedisHelper.GetObjectKey<T>(key);
        }
        /// <summary>
        /// Remove cache
        /// </summary>
        /// <param name="key">Cache key</param>
        public override void Remove(string key)
        {
            RedisHelper.KeyDelete(GetKey(key));
        }

        /// <summary>
        /// Set cache
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <param name="value"></param>
        /// <param name="duration"></param>
        public override void SetValue<T>(string key, T value, int duration)
        {
            var expire = TimeSpan.FromMinutes(duration);
            CheckDuration(expire);
            RedisHelper.SetStringKey<T>(key, value, expire);
        }

        /// <summary>
        /// Set Cache sliding expriation
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <param name="value"></param>
        /// <param name="duration"></param>
        public override void SetSliding<T>(string key, T value, int duration)
        {
            SetValue(key, value, duration);
        }

        /// <summary>
        /// Check duration
        /// </summary>
        /// <param name="expire"></param>
        private static void CheckDuration(TimeSpan expire)
        {
            if (expire <= TimeSpan.Zero)
            {
                throw new ArgumentException("Expiration value must be greater than zero.", nameof(expire));
            }
        }

        public override void Clear()
        {

        }
    }
}