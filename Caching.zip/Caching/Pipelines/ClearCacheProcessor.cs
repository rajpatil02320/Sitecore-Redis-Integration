﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SPJ.Foundation.Caching.Pipelines
{
    public class ClearCacheProcessor
    {
        public virtual void ClearCache(object sender, EventArgs args)
        {
            CacheHelper.Clear();
        }
    }
}